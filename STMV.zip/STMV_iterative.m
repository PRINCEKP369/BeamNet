function BTS = STMV_iterative(sig, N, OVRL, nb, sbin, ebin, sv, svy, d, c, fs, alpha)
% STMV_ITERATIVE  Iterative STMV beamformer — Zhu 2010 paper implementation.
%
%  Drop-in replacement for STMV.m / MVDR.m with identical BTS output.
%  Internally uses the iterative Woodbury rank-1 update to maintain R̂⁻¹
%  across calls instead of inverting from scratch each chunk.
%
%  Algorithm advantage (from paper Section 3):
%   Original STMV:    cost ∝ M³   (cubic in sensor count)
%   Iterative STMV:   cost ∝ M²   (quadratic — approx 2/M speedup)
%   At M=64:          approx 32× cheaper than original STMV per angle.
%
%  Twin array layout (256 sensors total):
%   Array A: sensors   1:128 → subarrays 1,2 (64 sensors each)
%   Array B: sensors 129:256 → subarrays 3,4 (64 sensors each)
%
%  Inputs:
%   sig    — [15000 x 256]        raw time-domain data
%   N      — NFFT (1500)
%   OVRL   — overlap samples (750)
%   nb     — number of blocks (20)
%   sbin   — first freq bin of band
%   ebin   — last  freq bin of band
%   sv     — [fbin x 64 x No_Ang] steering matrix, Array A
%   svy    — [fbin x 64 x No_Ang] steering matrix, Array B
%   d      — inter-element spacing in metres
%   c      — sound speed in m/s
%   fs     — sampling frequency in Hz
%   alpha  — forgetting factor (default: 2/3, paper's sea trial value)
%             Effective integration window = 1/alpha seconds.
%             alpha=2/3 → ~1.5s;  alpha=0.9 → ~10s
%
%  Output:
%   BTS    — [15000 x No_Ang]  beam time series (A+B combined, single)

    if nargin < 12 || isempty(alpha)
        alpha = 2/3;
    end

    %% ── Dimensions ───────────────────────────────────────────────────────
    m_total = size(sig, 2);          % 256
    sens    = m_total / 4;           % 64 per subarray
    No_Ang  = size(sv, 3);
    nOut    = (N - OVRL) * nb;       % 15000

    %% ── Persistent overlap buffer ────────────────────────────────────────
    persistent DataPrev
    if isempty(DataPrev)
        DataPrev = zeros(OVRL, sens, 4);
    end

    %% ── Step 1: Buffer into overlapping blocks [N x sens x nb x 4] ──────
    signal = zeros(N, sens, nb, 4);
    for s = 1:4
        cols = (s-1)*sens + 1 : s*sens;
        signal(:,:,:,s) = bufferarray(sig(:, cols), N, DataPrev(:,:,s));
        DataPrev(:,:,s) = signal(end-OVRL+1:end, :, end, s);
    end

    %% ── Step 2: FFT all subarrays, slice to band ─────────────────────────
    SFFT = fft(signal, N, 1);                    % [N x sens x nb x 4]
    sigb = single(SFFT(sbin:ebin, :, :, :));     % [fbin x sens x nb x 4]

    %% ── Step 3: Iterative STMV weights (Eqs. 8, 10–15) ─────────────────
    % STMV_iterative_weights maintains R̂⁻¹ persistently across calls.
    % Output weight: [fbin x sens x No_Ang] — identical layout to MVDR_weights.
    %
    % Array A: subarrays 1+2,  Array B: subarrays 3+4
    weight_A = single(STMV_iterative_weights(sigb(:,:,:,1:2), sv,  ...
                                              d, c, fs, N, sbin, ebin, alpha));
    weight_B = single(STMV_iterative_weights(sigb(:,:,:,3:4), svy, ...
                                              d, c, fs, N, sbin, ebin, alpha));

    %% ── Step 4: Batched beamforming (unchanged from MVDR/STMV) ──────────
    % Sum subarrays before beamforming: w·(x₁+x₂) = w·x₁ + w·x₂
    sigb_A_sum = sigb(:,:,:,1) + sigb(:,:,:,2);   % [fbin x sens x nb]
    sigb_B_sum = sigb(:,:,:,3) + sigb(:,:,:,4);

    % pagemtimes: [fbin x nb x sens] × [fbin x sens x No_Ang] → [fbin x nb x No_Ang]
    beamA = pagemtimes(permute(sigb_A_sum, [1,3,2]), conj(weight_A));
    beamB = pagemtimes(permute(sigb_B_sum, [1,3,2]), conj(weight_B));

    beam_band = beamA + beamB;                     % [fbin x nb x No_Ang]

    %% ── Step 5: Single IFFT on combined beam spectrum ────────────────────
    beam_full = zeros(N, nb, No_Ang, 'single');
    beam_full(sbin:ebin, :, :) = beam_band;
    ts = ifft(beam_full, [], 1, 'symmetric');       % [N x nb x No_Ang]

    %% ── Step 6: Remove overlap, reshape to continuous time series ────────
    ts  = ts(1:N-OVRL, :, :);
    BTS = single(reshape(ts, nOut, No_Ang));        % [15000 x No_Ang]

end
