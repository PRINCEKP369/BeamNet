function BTS = STMV(sig, N, OVRL, nb, sbin, ebin, sv, svy)
% STMV  Spatiotemporal MV beamformer for twin sonar array data.
%
%  Drop-in replacement for MVDR.m — identical 8-parameter interface.
%
%  To change the number of temporal taps, edit the single line:
%       L = 2;   ← change this value (see guide below)
%
%  L guide (m=64 sensors per subarray):
%   L=1  → spatial-only MVDR equivalent    covariance  64× 64
%   L=2  → original 2-bin stacking         covariance 128×128  (default)
%   L=3  → 3-bin stacking                  covariance 192×192  (~3.4× slower than L=2)
%   L=4  → 4-bin stacking                  covariance 256×256  (~8×   slower than L=2)
%  Beyond L=4 cost grows steeply (O(mL)³ per bin). Recommended: L=2 or L=3.
%
%  When to increase L:
%   - Targets are broadband and reverberation spans multiple freq bins
%   - You have headroom in your 1.2s budget (profile first)
%   - L=2 shows residual sidelobes that L=3 might suppress
%
%  Twin array layout (256 sensors total):
%   Array A: sensors   1:128 → subarrays 1,2 (64 sensors each)
%   Array B: sensors 129:256 → subarrays 3,4 (64 sensors each)
%
%  Inputs:
%   sig   — [15000 x 256]        raw time-domain data
%   N     — NFFT (1500)
%   OVRL  — overlap samples (750)
%   nb    — number of blocks (20)
%   sbin  — first freq bin of band
%   ebin  — last  freq bin of band
%   sv    — [fbin x 64 x No_Ang] steering matrix, Array A
%   svy   — [fbin x 64 x No_Ang] steering matrix, Array B
%
%  Output:
%   BTS   — [15000 x No_Ang]  beam time series (A+B combined, single)

    %% ── Tunable: number of temporal taps ────────────────────────────────
    % Change L here to test different stacking depths.
    % STMV_weights.m handles all edge cases automatically.
    L = 2;   % ← CHANGE THIS to test L=1, L=2, L=3, L=4 etc.

    %% ── Dimensions ───────────────────────────────────────────────────────
    m      = size(sig, 2);           % 256 total sensors
    sens   = m / 4;                  % 64 per subarray
    No_Ang = size(sv, 3);
    nOut   = (N - OVRL) * nb;        % 750 * 20 = 15000

    %% ── Persistent overlap buffer ────────────────────────────────────────
    persistent DataPrev
    if isempty(DataPrev)
        DataPrev = zeros(OVRL, sens, 4);
    end

    %% ── Step 1: Buffer into overlapping blocks [N x sens x nb x 4] ──────
    signal = zeros(N, sens, nb, 4);
    for s = 1:4
        cols = (s-1)*sens + 1 : s*sens;
        signal(:,:,:,s) = bufferarray(sig(:, cols), N, DataPrev(:,:,s));
        DataPrev(:,:,s) = signal(end-OVRL+1:end, :, end, s);
    end

    %% ── Step 2: FFT all subarrays, slice to band ─────────────────────────
    SFFT = fft(signal, N, 1);                    % [N x sens x nb x 4]
    sigb = single(SFFT(sbin:ebin, :, :, :));     % [fbin x sens x nb x 4]

    %% ── Step 3: STMV weights ─────────────────────────────────────────────
    % Pass L through to STMV_weights. The persistent covariance resets
    % automatically if L changes between calls.
    weight_A = single(STMV_weights(sigb(:,:,:,1:2), sv,  L));
    weight_B = single(STMV_weights(sigb(:,:,:,3:4), svy, L));

    %% ── Step 4: Batched beamforming ──────────────────────────────────────
    sigb_A_sum = sigb(:,:,:,1) + sigb(:,:,:,2);   % [fbin x sens x nb]
    sigb_B_sum = sigb(:,:,:,3) + sigb(:,:,:,4);

    beamA = pagemtimes(permute(sigb_A_sum, [1,3,2]), conj(weight_A));
    beamB = pagemtimes(permute(sigb_B_sum, [1,3,2]), conj(weight_B));

    beam_band = beamA + beamB;                     % [fbin x nb x No_Ang]

    %% ── Step 5: Single IFFT on combined beam spectrum ────────────────────
    beam_full = zeros(N, nb, No_Ang, 'single');
    beam_full(sbin:ebin, :, :) = beam_band;
    ts = ifft(beam_full, [], 1, 'symmetric');       % [N x nb x No_Ang]

    %% ── Step 6: Remove overlap, reshape to time series ───────────────────
    ts  = ts(1:N-OVRL, :, :);
    BTS = single(reshape(ts, nOut, No_Ang));         % [15000 x No_Ang]

end
