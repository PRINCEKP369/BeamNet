function weight = STMV_weights(signal, sv, L)
% STMV_WEIGHTS  Spatiotemporal MV weight vectors for all frequency bins.
%
%  Generalised to support L >= 1 temporal taps (adjacent frequency bins).
%  At each centre bin f, the spatiotemporal snapshot stacks bins f..f+L-1:
%
%    x_st(f) = [ x(f)     ]   size [m*L x ns]
%              [ x(f+1)   ]
%              [   ...    ]
%              [ x(f+L-1) ]
%
%  The covariance is [m*L x m*L] per bin, and the spatiotemporal steering
%  vector stacks L consecutive per-bin steering vectors:
%
%    s_st(f) = [ s(f)     ]   size [m*L x No_Ang]
%              [ s(f+1)   ]
%              [   ...    ]
%              [ s(f+L-1) ]
%
%  Edge handling: for the last L-1 bins that lack L forward neighbours,
%  the final available bin is repeated to pad — equivalent to falling back
%  toward spatial-only MVDR at those edge bins.
%
%  Inputs:
%   signal  — [fbin x m x nb x nSub]  freq-domain subarray data
%   sv      — [fbin x m x No_Ang]     steering matrix (per-bin, per-sensor)
%   L       — number of temporal taps (default: 2)
%             L=1 → equivalent to spatial-only MVDR (no stacking)
%             L=2 → original 2-bin stacking (128x128 cov for m=64)
%             L=3 → 192x192 cov, ~3.4x more expensive than L=2
%             L=4 → 256x256 cov, ~8x more expensive than L=2
%             Recommended range: 2–4. Beyond L=4 cost grows steeply.
%
%  Output:
%   weight  — [fbin x m x No_Ang]  element-space weights
%             (same layout as MVDR_weights — fully drop-in compatible)

    if nargin < 3 || isempty(L)
        L = 2;   % default: original 2-bin stacking
    end
    assert(L >= 1 && L == floor(L), 'L must be a positive integer');

    signal = double(signal);
    sv     = double(sv);

    alpha = 0.9;
    fbin  = size(signal, 1);
    m     = size(signal, 2);
    nb    = size(signal, 3);
    nSub  = size(signal, 4);
    nAng  = size(sv, 3);
    mL    = m * L;           % spatiotemporal snapshot length: m*L

    %% ── Persistent covariance [mL x mL x fbin] ──────────────────────────
    % Reset whenever L, m, or fbin changes (e.g. switching L mid-run).
    persistent R_st R_size
    if isempty(R_st) || ~isequal(R_size, [mL, fbin])
        R_st   = zeros(mL, mL, fbin);
        R_size = [mL, fbin];
        fprintf('[STMV_weights] Initialised: m=%d L=%d → covariance %dx%d, fbin=%d\n',...
                m, L, mL, mL, fbin);
    end

    %% ── Step 1: Reshape snapshots → [m x ns x fbin] ─────────────────────
    ns    = nb * nSub;
    sig2d = reshape(signal, fbin, m, ns);   % [fbin x m x ns]
    sig2d = permute(sig2d, [2, 3, 1]);      % [m x ns x fbin]

    %% ── Step 2: Build spatiotemporal snapshot array [mL x ns x fbin] ────
    % For each centre bin f, stack L bins: f, f+1, ..., f+L-1.
    % For edge bins where f+l-1 > fbin, repeat the last available bin.
    sig_st = zeros(mL, ns, fbin);
    for l = 1:L
        rows = (l-1)*m + 1 : l*m;          % row block for tap l
        % Source bin index for tap l: min(f+l-1, fbin) — clamp at edge
        src_bins = min((1:fbin) + (l-1), fbin);   % [1 x fbin] clamped indices
        % Vectorised assignment across all fbin pages at once
        sig_st(rows, :, :) = sig2d(:, :, src_bins);
    end
    % sig_st: [mL x ns x fbin]

    %% ── Step 3: Recursive covariance update — all bins, one pagemtimes ──
    % [mL x ns x fbin] × [mL x ns x fbin]' → [mL x mL x fbin]
    XXT  = pagemtimes(sig_st, 'none', sig_st, 'ctranspose');
    R_st = R_st * (1 - alpha) + XXT * alpha;

    %% ── Step 4: Diagonal loading ─────────────────────────────────────────
    % trace via diagonal index sum — R2021a compatible (no pagetrace needed)
    diagIdx = 1 : mL+1 : mL*mL;
    Rmat    = reshape(R_st, mL*mL, fbin);
    tr      = reshape(sum(Rmat(diagIdx, :), 1), 1, 1, fbin);  % [1 x 1 x fbin]
    I3      = repmat(eye(mL), 1, 1, fbin);                    % [mL x mL x fbin]
    Hr      = R_st + 10e-3 * I3 .* tr;                        % [mL x mL x fbin]

    %% ── Step 5: Build spatiotemporal steering vectors [mL x nAng x fbin] ─
    sv_p  = permute(sv, [2, 3, 1]);          % [m x nAng x fbin]
    sv_st = zeros(mL, nAng, fbin);
    for l = 1:L
        rows     = (l-1)*m + 1 : l*m;
        src_bins = min((1:fbin) + (l-1), fbin);
        sv_st(rows, :, :) = sv_p(:, :, src_bins);
    end
    % sv_st: [mL x nAng x fbin]

    %% ── Step 6: Cholesky solve on [mL x mL] per bin ─────────────────────
    % Cost per bin: O(mL³)
    %   L=2: 128³ ≈ 2.1M ops   L=3: 192³ ≈ 7.1M ops   L=4: 256³ ≈ 16.8M ops
    weight_st = zeros(mL, nAng, fbin);

    for i = 1:fbin
        Hi = Hr(:, :, i);          % [mL x mL]
        si = sv_st(:, :, i);       % [mL x nAng]

        [Lc, p] = chol(Hi, 'lower');
        if p == 0
            RinvS = Lc' \ (Lc \ si);   % two triangular solves
        else
            RinvS = Hi \ si;            % fallback if not positive-definite
        end

        % Denominator: sᴴ R⁻¹ s per angle [1 x nAng]
        denom            = sum(conj(si) .* RinvS, 1);
        weight_st(:,:,i) = RinvS ./ denom;             % [mL x nAng]
    end

    %% ── Step 7: Extract top-m rows — element-space weights ───────────────
    % The spatiotemporal weight vector is [mL x nAng].
    % Only the top m rows (tap 0, bin f) are applied to the signal at bin f.
    % This is standard subvector extraction for frequency-domain STMV.
    % Layout: [m x nAng x fbin] → permute → [fbin x m x nAng]
    weight = permute(weight_st(1:m, :, :), [3, 1, 2]);   % [fbin x m x nAng]

end
