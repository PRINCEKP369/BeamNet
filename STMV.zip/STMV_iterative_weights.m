function weight = STMV_iterative_weights(signal, sv, d, c, fs, N, sbin, ebin, alpha)
% STMV_ITERATIVE_WEIGHTS  Iterative STMV weights using Zhu 2010 algorithm.
%
%  Implements exactly Equations 8, 10–15 from:
%  Zhu et al. "Iterative Algorithm of Steered Minimum Variance and Its
%  Application in Weak Targets Detection." J. Shanghai Jiaotong Univ. 2010.
%
%  Key difference from standard STMV_weights.m:
%   Standard STMV: builds [128x128] covariance then Cholesky-solves per bin.
%   Iterative STMV: steers FIRST per angle, then updates R⁻¹ incrementally
%                   using the Woodbury rank-1 identity across frequency bins.
%                   Cost is O(M²) per angle vs O(M³) — approx 2/M speedup.
%
%  The algorithm runs in ANGLE-OUTER order (matching the paper exactly):
%   For each angle θ:
%     Step 1. Steer summed spectrum:  U(f_k,θ) = T_D(f_k,θ) · X̄(f_k)   [Eq.11]
%     Step 2. Start chain at f_l:    R̂⁻¹(l)  via Eq.15 using prev R̂⁻¹
%     Step 3. Propagate f_l+1→f_J:  R̂⁻¹(k)  via Eq.14 (rank-1 update)
%     Step 4. Compute weights:        W = R̂⁻¹·I_M / (I_Mᴴ·R̂⁻¹·I_M)   [Eq.8]
%
%  Inputs:
%   signal  — [fbin x M x nb x nSub]  freq-domain subarray data (double/single)
%             NOTE: this is the band-extracted FFT output, already sliced
%             to sbin:ebin along dimension 1.
%   sv      — [fbin x M x No_Ang]     element-space steering matrix
%   d       — inter-element spacing (metres)
%   c       — sound speed (m/s)
%   fs      — sampling frequency (Hz)
%   N       — NFFT length (e.g. 1500)
%   sbin    — first frequency bin index of band (in full N-point spectrum)
%   ebin    — last  frequency bin index of band
%   alpha   — forgetting factor 0<alpha<1 (paper recommends 2/3)
%
%  Output:
%   weight  — [fbin x M x No_Ang]  element-space MVDR weight vectors
%              Same layout as MVDR_weights / STMV_weights — drop-in.
%
%  Persistent state:
%   Rinv_persist — [M x M x No_Ang]  R̂⁻¹_stmv per angle, maintained
%                  across calls via the one-phase regressive filter (Eq.13).
%                  Resets automatically if dimensions change.

    signal = double(signal);
    sv     = double(sv);

    fbin  = size(signal, 1);
    M     = size(signal, 2);
    nb    = size(signal, 3);
    nSub  = size(signal, 4);
    nAng  = size(sv, 3);

    %% ── Frequency axis for band bins sbin:ebin ───────────────────────────
    % f_k in Hz for each bin k = sbin..ebin
    freqs = ((sbin-1 : ebin-1)) * (fs / N);   % [1 x fbin] Hz

    %% ── Persistent R̂⁻¹_stmv [M x M x No_Ang] ──────────────────────────
    % One inverse steered covariance per scan angle.
    % Initialised as (1/delta)·I which corresponds to a zero prior on R.
    % Reset whenever M, No_Ang, or fbin changes.
    persistent Rinv_persist state_size
    expected_size = [M, nAng, fbin];
    if isempty(Rinv_persist) || ~isequal(state_size, expected_size)
        delta         = 1e-4;                          % initialisation loading
        Rinv_init     = (1/delta) * eye(M);
        Rinv_persist  = repmat(Rinv_init, 1, 1, nAng); % [M x M x nAng]
        state_size    = expected_size;
        fprintf('[STMV_iterative_weights] Initialised: M=%d nAng=%d fbin=%d alpha=%.3f\n',...
                M, nAng, fbin, alpha);
    end

    %% ── Step 1 (Eq. 10): Sum snapshots across blocks and subarrays ───────
    % X̄(f_k) = Σ_n X(f_k)_n
    % signal is [fbin x M x nb x nSub] — sum over dims 3 and 4
    % Result: Xsum [fbin x M]
    ns   = nb * nSub;
    Xsum = sum(reshape(signal, fbin, M, ns), 3);   % [fbin x M]
    % Permute to [M x fbin] for convenient column-per-bin access
    Xsum = permute(Xsum, [2, 1]);                  % [M x fbin]

    %% ── Precompute T_D phase factors for all angles and bins ─────────────
    % T_D(f_k, θ) is diagonal → store as [M x fbin] phase vector per angle.
    % phase(m, k, ang) = exp(j·2π·f_k·m·d·cosθ/c),  m=0..M-1
    m_idx = (0:M-1).';                              % [M x 1]
    % cos_angles: [1 x 1 x nAng]
    theta_rad  = permute(sv(1,1,:)*0, [3,2,1]);    % placeholder shape trick
    % Extract scan angles from the steering matrix phase structure.
    % sv(f,m,ang) = exp(-j·2π·f·m·d·sinθ/c) — recover cosθ from first bin
    % Instead, recompute T_D directly from d,c,fs,N using the same angle
    % convention as sv. sv uses sinθ (end-fire convention 0-180°).
    % T_D in the paper uses cosθ — we match sv's convention: use sinθ.
    %
    % Recover sin(θ) from sv at bin sbin, sensors 0 and 1:
    % sv(1,2,ang)/sv(1,1,ang) = exp(-j·2π·freqs(1)·d·sinθ/c)
    % → sinθ = angle(sv(1,2,ang)/sv(1,1,ang)) * c / (2π·freqs(1)·d)
    sv1  = squeeze(sv(1, 1, :));   % [nAng x 1]
    sv2  = squeeze(sv(1, 2, :));   % [nAng x 1]
    sin_theta = angle(sv2 ./ sv1) * c / (2*pi * freqs(1) * d);  % [nAng x 1]
    sin_theta = sin_theta(:).';    % [1 x nAng]

    % phase_all: [M x fbin x nAng]
    % phase_all(m,k,ang) = exp(j·2π·freqs(k)·(m)·d·sinθ(ang)/c)
    % Note: + sign here because T_D compensates (removes) the arrival delay
    phase_all = exp(1j * 2*pi * d/c * ...
        m_idx ...                          % [M x 1 x 1]
        .* reshape(freqs, 1, fbin, 1) ...  % [1 x fbin x 1]
        .* reshape(sin_theta, 1, 1, nAng));% [1 x 1 x nAng]
    % phase_all: [M x fbin x nAng]

    %% ── Main loop: one iteration of Eqs 15 + 14 per angle ───────────────
    % Output weight: [M x nAng x fbin] then permuted at end
    weight_out = zeros(M, nAng, fbin);

    I_M = ones(M, 1);   % all-ones vector (distortionless constraint)

    for ang = 1:nAng

        %% Step 2 (Eq. 11): Steer summed spectrum for this angle ───────────
        % U(f_k, θ) = T_D(f_k, θ) · X̄(f_k)
        % T_D is diagonal → element-wise multiply phase vector with Xsum
        % phase_all(:,:,ang): [M x fbin], Xsum: [M x fbin]
        U = phase_all(:,:,ang) .* Xsum;   % [M x fbin]

        %% Step 3 (Eq. 15): First bin update — incorporates alpha ──────────
        % Uses R̂⁻¹(n-1) from previous time chunk (or init).
        % R̂⁻¹(l) = (1/α) · [ ((α-1)/(α+(1-α)·uᴴ·R̂⁻¹(n-1)·u)) · (R̂⁻¹u·uᴴR̂⁻¹)
        %                     + R̂⁻¹(n-1) ]
        Rinv = Rinv_persist(:, :, ang);   % [M x M] — current inverse

        u   = U(:, 1);              % [M x 1] steered vector at bin f_l
        Rv  = Rinv * u;             % [M x 1] cost: M²
        uRv = real(u' * Rv);        % scalar:  uᴴ·R̂⁻¹·u

        denom_15 = alpha + (1 - alpha) * uRv;
        Rinv = (1/alpha) * ( ((alpha - 1) / denom_15) * (Rv * Rv') + Rinv );
        % Rinv now = R̂⁻¹_stmv(l): the inverse after first bin + temporal update

        %% Step 4 (Eq. 14): Propagate through remaining bins f_l+1 → f_J ──
        % R̂⁻¹(k) = R̂⁻¹(k-1)
        %   + (α-1)·R̂⁻¹(k-1)·u·uᴴ·R̂⁻¹(k-1) / (1+(1-α)·uᴴ·R̂⁻¹(k-1)·u)
        for k = 2:fbin
            u   = U(:, k);          % [M x 1] steered vector at bin f_k
            Rv  = Rinv * u;         % [M x 1] cost: M²
            uRv = real(u' * Rv);    % scalar

            denom_14 = 1 + (1 - alpha) * uRv;
            Rinv = Rinv + ((alpha - 1) / denom_14) * (Rv * Rv');
            % Rinv now = R̂⁻¹_stmv(k): updated through bin f_k
        end

        %% Step 5: Store updated R̂⁻¹ for next time chunk ──────────────────
        Rinv_persist(:, :, ang) = Rinv;

        %% Step 6 (Eq. 8): Compute weight vector ───────────────────────────
        % W = R̂⁻¹_stmv · I_M / (I_Mᴴ · R̂⁻¹_stmv · I_M)
        % The all-ones vector I_M replaces the steering vector because the
        % data has already been steered toward θ via T_D in Step 2.
        RinvI  = Rinv * I_M;             % [M x 1] cost: M²
        denom_W = real(I_M' * RinvI);    % scalar: I_Mᴴ·R̂⁻¹·I_M
        W      = RinvI / denom_W;        % [M x 1] STMV weight vector

        %% Step 7: Distribute W across all freq bins for this angle ─────────
        % The weight is the same for all bins (steered covariance is already
        % broadband — it integrates across all bins via Eq.13/14/15).
        % Replicate W across fbin dimension.
        weight_out(:, ang, :) = repmat(W, 1, 1, fbin);   % [M x 1 x fbin]
    end

    %% ── Permute to [fbin x M x nAng] — matches MVDR_weights layout ───────
    weight = permute(weight_out, [3, 1, 2]);   % [fbin x M x nAng]

end
