function [h, H] = build_CBS_filter(M, L, theta_pass_deg, theta_stop_deg, d, lambda)
% BUILD_CBS_FILTER  Design an FIR filter for Convolutional Beamspace (CBS).
%
%  Implements the filter design for CBS as described in:
%  Chen & Vaidyanathan, "Convolutional beamspace for linear arrays,"
%  IEEE Trans. Signal Processing, 2020.
%
%  The filter h(n) of length L is designed as a spatial bandpass filter
%  whose passband covers the angular sector of interest. The banded
%  Toeplitz matrix H derived from h(n) maps the M-sensor array output
%  to (M-L+1) beamspace samples, preserving the Vandermonde structure
%  of the steering vectors (unlike classical DFT beamspace).
%
%  Inputs:
%   M              — number of sensors per subarray (e.g. 64)
%   L              — FIR filter length (e.g. 9, 13, 17)
%                    Beamspace dimension = M - L + 1
%                    Larger L → narrower passband, stronger out-of-band rejection
%                    but smaller beamspace and fewer degrees of freedom.
%                    Recommended: L = 9 to 17 for M = 64.
%   theta_pass_deg — passband edge in degrees (e.g. 60 for 0-60° sector)
%   theta_stop_deg — stopband edge in degrees (e.g. 80 for 80-90° stop)
%   d              — inter-element spacing in metres
%   lambda         — wavelength at centre frequency = c / f_centre
%
%  Outputs:
%   h  — [L x 1]            FIR filter coefficients
%   H  — [(M-L+1) x M]      banded Toeplitz convolution matrix (Eq. 3)
%
%  Usage:
%   f_centre = ((sbin+ebin)/2) * (fs/N);
%   [h, H_mat] = build_CBS_filter(64, 9, 80, 90, d, c/f_centre);
%
%  Design notes:
%   - Passband is defined in spatial frequency ω = 2π·d·sinθ/λ ∈ [-π, π]
%   - Filter is designed using firpm (Parks-McClellan equiripple method)
%   - For a full 180° sector use theta_pass=85°, theta_stop=89°
%   - For a focused sector (e.g. bow sector) use theta_pass=60°, theta_stop=75°

    %% ── Convert angle sector to spatial frequency ────────────────────────
    % Spatial frequency: omega = 2*pi*d/lambda * sin(theta)
    % For ULA with spacing d and wavelength lambda:
    omega_pass = 2*pi * d/lambda * sind(theta_pass_deg);  % passband edge
    omega_stop = 2*pi * d/lambda * sind(theta_stop_deg);  % stopband edge

    % Normalise to [0, 1] where 1 = pi (Nyquist) for firpm
    % firpm expects frequencies normalised so that pi maps to 1
    f_pass = omega_pass / pi;
    f_stop = omega_stop / pi;

    % Clamp to valid range [0, 1]
    f_pass = min(max(f_pass, 0.01), 0.95);
    f_stop = min(max(f_stop, f_pass + 0.02), 0.99);

    %% ── Design FIR filter via Parks-McClellan (Eq. after Eq.7 in paper) ──
    % Symmetric lowpass filter — passband [0, f_pass], stopband [f_stop, 1]
    % L must be odd for Type I linear-phase FIR (symmetric, odd length)
    if mod(L, 2) == 0
        L = L + 1;   % ensure odd length for Type I
        warning('[build_CBS_filter] L adjusted to %d (must be odd for Type I FIR)', L);
    end

    % firpm: [0 f_pass f_stop 1] with desired amplitudes [1 1 0 0]
    % Weights: equal ripple in pass and stop bands
    h = firpm(L-1, [0, f_pass, f_stop, 1], [1, 1, 0, 0], [1, 1]);
    h = h(:);   % ensure column vector [L x 1]

    %% ── Build banded Toeplitz convolution matrix H ───────────────────────
    % H is (M-L+1) × M  (Eq. 3 in paper)
    % Row i of H contains h(L-1)...h(0) starting at column i
    % This implements the steady-state convolution output samples
    B = M - L + 1;   % beamspace dimension
    H = zeros(B, M);
    h_rev = flipud(h);   % h(L-1), h(L-2), ..., h(0) — reversed for convolution
    for i = 1:B
        H(i, i:i+L-1) = h_rev.';
    end
    % H: [B x M]  banded Toeplitz matrix
    % Apply as:  y = H * x  where x is [M x 1] → y is [B x 1]

    fprintf('[build_CBS_filter] M=%d L=%d B=%d (beamspace dim) f_pass=%.3f f_stop=%.3f\n',...
            M, L, B, f_pass, f_stop);
end
