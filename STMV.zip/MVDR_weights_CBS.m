function weight_elem = MVDR_weights_CBS(signal, sv, H_cbs)
% MVDR_WEIGHTS_CBS  MVDR weights using Convolutional Beamspace (CBS).
%
%  Implements CBS-MVDR as described in Chen & Vaidyanathan (IEEE TSP 2020):
%  "Convolutional beamspace for linear arrays", Sections II-A, II-B, II-C.
%
%  Key idea (Eq. 3-6 of paper):
%   Instead of running MVDR directly on M=64 sensors, we first apply the
%   banded Toeplitz filter matrix H_cbs to project from M sensors down to
%   B = M-L+1 beamspace samples. MVDR is then solved in this smaller B×B
%   space. Because H_cbs is Toeplitz (not an arbitrary fat matrix), the
%   Vandermonde structure of the steering vectors is preserved, meaning
%   the projected steering vectors sv_bs = H_cbs·sv are still valid
%   distortionless constraints for MVDR.
%
%  The weight in element space is recovered as:
%   w_elem = H_cbs' * w_bs   (adjoint mapping, Eq. 6 + beamforming step)
%
%  This gives the same output as element-space MVDR but with covariance
%  inversion on [B×B] instead of [M×M]:
%   B = M - L + 1
%   L=9  → B=56  (inversion 2.3× cheaper than M=64)
%   L=17 → B=48  (inversion 3.4× cheaper)
%   L=33 → B=32  (inversion 8×   cheaper)
%
%  Inputs:
%   signal    — [fbin x m x nb x nSub]  freq-domain element-space data
%   sv        — [fbin x m x No_Ang]     element-space steering matrix
%   H_cbs     — [B x m]                CBS Toeplitz matrix (from build_CBS_filter)
%
%  Output:
%   weight_elem — [fbin x m x No_Ang]  element-space MVDR weights
%                 Same layout as MVDR_weights — fully drop-in compatible.
%
%  Persistent state:
%   R_bs_persist — [B x B x fbin]  beamspace covariance, maintained across
%                  calls via one-phase regressive filter (same as MVDR_weights).

    signal = double(signal);
    sv     = double(sv);
    H_cbs  = double(H_cbs);

    alpha  = 0.9;
    fbin   = size(signal, 1);
    m      = size(signal, 2);
    nb     = size(signal, 3);
    nSub   = size(signal, 4);
    nAng   = size(sv, 3);
    B      = size(H_cbs, 1);   % beamspace dimension = M - L + 1

    %% ── Persistent beamspace covariance [B x B x fbin] ──────────────────
    persistent R_bs_persist R_bs_size
    if isempty(R_bs_persist) || ~isequal(R_bs_size, [B, fbin])
        R_bs_persist = zeros(B, B, fbin);
        R_bs_size    = [B, fbin];
        fprintf('[MVDR_weights_CBS] Initialised: m=%d B=%d fbin=%d alpha=%.2f\n',...
                m, B, fbin, alpha);
    end

    %% ── Step 1: Project element-space snapshots into CBS beamspace ───────
    % x_elem: [m x ns x fbin]  →  y_bs = H_cbs · x_elem: [B x ns x fbin]
    %
    % H_cbs is [B x m]. We replicate it across fbin pages for pagemtimes.
    % This is the core CBS operation (Eq. 3): y = H * x
    ns    = nb * nSub;
    sig2d = reshape(signal, fbin, m, ns);   % [fbin x m x ns]
    sig2d = permute(sig2d, [2, 3, 1]);      % [m x ns x fbin]

    % H_rep: [B x m x fbin] — same H replicated across freq pages
    H_rep  = repmat(H_cbs, 1, 1, fbin);     % [B x m x fbin]

    % Project to beamspace: [B x ns x fbin]
    % pagemtimes: [B x m x fbin] × [m x ns x fbin] → [B x ns x fbin]
    sig_bs = pagemtimes(H_rep, sig2d);       % [B x ns x fbin]

    %% ── Step 2: Recursive beamspace covariance update ────────────────────
    % Same recursive formula as MVDR_weights but now [B×B] not [M×M]
    % [B x ns x fbin] × [B x ns x fbin]' → [B x B x fbin]
    XXT_bs       = pagemtimes(sig_bs, 'none', sig_bs, 'ctranspose');
    R_bs_persist = R_bs_persist * (1 - alpha) + XXT_bs * alpha;

    %% ── Step 3: Diagonal loading on beamspace covariance ─────────────────
    diagIdx = 1 : B+1 : B*B;
    Rmat    = reshape(R_bs_persist, B*B, fbin);
    tr      = reshape(sum(Rmat(diagIdx, :), 1), 1, 1, fbin);  % [1 x 1 x fbin]
    I3      = repmat(eye(B), 1, 1, fbin);
    Hr_bs   = R_bs_persist + 10e-3 * I3 .* tr;               % [B x B x fbin]

    %% ── Step 4: Project steering vectors into CBS beamspace ──────────────
    % sv_elem: [fbin x m x nAng] → permute → [m x nAng x fbin]
    % sv_bs = H_cbs · sv_elem → [B x nAng x fbin]
    %
    % This is valid because H_cbs is Toeplitz — the Vandermonde structure
    % of the steering vectors is preserved (Eq. 4-6 of the paper).
    % The projected steering vector H·a(θ) ≈ H(e^jω)·a_{M-L+1}(θ)
    % still points toward θ, so MVDR's distortionless constraint holds.
    sv_p  = permute(sv, [2, 3, 1]);                            % [m x nAng x fbin]
    sv_bs = pagemtimes(H_rep, sv_p);                           % [B x nAng x fbin]

    %% ── Step 5: Solve MVDR in beamspace — Cholesky on [B×B] per bin ──────
    % B < M so each solve is cheaper: B³ vs M³
    % L=9,M=64 → B=56: 56³/64³ = 0.67 (33% cheaper per bin)
    % L=17,M=64→ B=48: 48³/64³ = 0.42 (58% cheaper)
    weight_bs = zeros(B, nAng, fbin);

    for i = 1:fbin
        Hi = Hr_bs(:, :, i);       % [B x B]
        si = sv_bs(:, :, i);       % [B x nAng]

        [Lc, p] = chol(Hi, 'lower');
        if p == 0
            RinvS = Lc' \ (Lc \ si);
        else
            RinvS = Hi \ si;
        end

        % Denominator: sᴴ R⁻¹ s per angle [1 x nAng]
        denom            = sum(conj(si) .* RinvS, 1);
        weight_bs(:,:,i) = RinvS ./ denom;              % [B x nAng]
    end

    %% ── Step 6: Map beamspace weights back to element space ──────────────
    % w_elem = H_cbs' * w_bs   [m x nAng x fbin]
    %
    % This recovers the full M-sensor weight vector from the B-dimensional
    % beamspace solution. H_cbs' is [m x B].
    % pagemtimes: [m x B x fbin] × [B x nAng x fbin] → [m x nAng x fbin]
    H_rep_H    = permute(H_rep, [2, 1, 3]);             % [m x B x fbin] (H_cbs')
    weight_p   = pagemtimes(H_rep_H, weight_bs);        % [m x nAng x fbin]

    %% ── Step 7: Permute to [fbin x m x nAng] ────────────────────────────
    weight_elem = permute(weight_p, [3, 1, 2]);

end
