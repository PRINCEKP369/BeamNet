function BTS = MVDR_CBS(sig, N, OVRL, nb, sbin, ebin, sv, svy, d, c, fs)
% MVDR_CBS  MVDR beamformer with Convolutional Beamspace (CBS) pre-processing.
%
%  Implements CBS-MVDR based on Chen & Vaidyanathan (IEEE TSP 2020).
%  CBS projects the M=64 sensor array into a smaller B-dimensional
%  beamspace using a banded Toeplitz FIR filter matrix, runs MVDR on
%  the reduced covariance, then maps weights back to element space.
%
%  Unlike classical DFT beamspace, CBS preserves the Vandermonde structure
%  of steering vectors — so MVDR's distortionless constraint is exact in
%  beamspace, not approximate. No correction steps needed.
%
%  Twin array layout (256 sensors total):
%   Array A: sensors   1:128 → subarrays 1,2 (64 sensors each)
%   Array B: sensors 129:256 → subarrays 3,4 (64 sensors each)
%
%  Inputs:
%   sig   — [15000 x 256]        raw time-domain data
%   N     — NFFT (1500)
%   OVRL  — overlap samples (750)
%   nb    — number of blocks (20)
%   sbin  — first freq bin of band
%   ebin  — last  freq bin of band
%   sv    — [fbin x 64 x No_Ang] steering matrix, Array A
%   svy   — [fbin x 64 x No_Ang] steering matrix, Array B
%   d     — inter-element spacing in metres
%   c     — sound speed in m/s
%   fs    — sampling frequency in Hz
%
%  Output:
%   BTS   — [15000 x No_Ang]  beam time series (A+B combined, single)
%
%  ── CBS tuning parameters (adjust here) ──────────────────────────────────
%  L controls the trade-off between beamspace reduction and angular coverage:
%
%   L=9  → B=56  covariance 56×56  (mild reduction, wide passband)
%   L=17 → B=48  covariance 48×48  (moderate reduction)
%   L=33 → B=32  covariance 32×32  (strong reduction, sharper filter)
%
%  theta_pass_deg: angles within this from broadside are kept (passband)
%  theta_stop_deg: angles beyond this are suppressed (stopband)
%  Set theta_pass=85, theta_stop=89 to cover nearly the full 0-180° sector.

    %% ── CBS tuning ────────────────────────────────────────────────────────
    L              = 17;    % FIR filter length — must be odd
    theta_pass_deg = 80;    % passband edge (degrees from broadside)
    theta_stop_deg = 88;    % stopband edge (degrees)

    %% ── Dimensions ───────────────────────────────────────────────────────
    m_total = size(sig, 2);          % 256
    sens    = m_total / 4;           % 64 per subarray
    No_Ang  = size(sv, 3);
    nOut    = (N - OVRL) * nb;       % 15000

    %% ── Persistent: overlap buffer + CBS filter matrix ───────────────────
    % H_cbs is built once at centre frequency and reused every call.
    % Resets automatically if parameters change.
    persistent DataPrev H_A H_B

    if isempty(DataPrev)
        DataPrev = zeros(OVRL, sens, 4);
    end

    if isempty(H_A)
        f_centre = ((sbin + ebin) / 2) * (fs / N);
        lambda   = c / f_centre;

        % Build CBS Toeplitz matrix for each array
        % Both arrays have same geometry here, kept separate for flexibility
        [~, H_A] = build_CBS_filter(sens, L, theta_pass_deg, theta_stop_deg, d, lambda);
        [~, H_B] = build_CBS_filter(sens, L, theta_pass_deg, theta_stop_deg, d, lambda);

        B = sens - L + 1;
        fprintf('[MVDR_CBS] CBS filter built: m=%d L=%d B=%d f_centre=%.1f Hz\n',...
                sens, L, B, f_centre);
        fprintf('[MVDR_CBS] Covariance size: %d×%d vs element-space %d×%d\n',...
                B, B, sens, sens);
    end

    %% ── Step 1: Buffer into overlapping blocks [N x sens x nb x 4] ──────
    signal = zeros(N, sens, nb, 4);
    for s = 1:4
        cols = (s-1)*sens + 1 : s*sens;
        signal(:,:,:,s) = bufferarray(sig(:, cols), N, DataPrev(:,:,s));
        DataPrev(:,:,s) = signal(end-OVRL+1:end, :, end, s);
    end

    %% ── Step 2: FFT all subarrays, slice to band ─────────────────────────
    SFFT = fft(signal, N, 1);                    % [N x sens x nb x 4]
    sigb = single(SFFT(sbin:ebin, :, :, :));     % [fbin x sens x nb x 4]

    %% ── Step 3: CBS-MVDR weights ─────────────────────────────────────────
    % MVDR_weights_CBS projects to beamspace internally, solves on [B×B],
    % maps back to element space. Output is [fbin x sens x No_Ang] —
    % identical layout to MVDR_weights, so beamforming is unchanged.
    weight_A = single(MVDR_weights_CBS(sigb(:,:,:,1:2), sv,  H_A));
    weight_B = single(MVDR_weights_CBS(sigb(:,:,:,3:4), svy, H_B));

    %% ── Step 4: Batched beamforming (identical to MVDR.m) ───────────────
    sigb_A_sum = sigb(:,:,:,1) + sigb(:,:,:,2);
    sigb_B_sum = sigb(:,:,:,3) + sigb(:,:,:,4);

    beamA = pagemtimes(permute(sigb_A_sum, [1,3,2]), conj(weight_A));
    beamB = pagemtimes(permute(sigb_B_sum, [1,3,2]), conj(weight_B));

    beam_band = beamA + beamB;                     % [fbin x nb x No_Ang]

    %% ── Step 5: Single IFFT on combined beam spectrum ────────────────────
    beam_full = zeros(N, nb, No_Ang, 'single');
    beam_full(sbin:ebin, :, :) = beam_band;
    ts = ifft(beam_full, [], 1, 'symmetric');       % [N x nb x No_Ang]

    %% ── Step 6: Remove overlap, reshape to time series ───────────────────
    ts  = ts(1:N-OVRL, :, :);
    BTS = single(reshape(ts, nOut, No_Ang));         % [15000 x No_Ang]

end
